// const mongoose = require("mongoose");
// const WorkoutHistory = require("../models/WorkoutHistory");

// mongoose.connect("mongodb://localhost/exereaseDB", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// const workoutHistorySeed = [
//   {
//     date: new Date(),
//     type: "Running",
//     duration: 60,
//     calories: 500,
//   },
// ];
